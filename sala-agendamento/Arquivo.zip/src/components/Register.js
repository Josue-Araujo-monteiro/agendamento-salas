// src/components/Register.js
import React from 'react';

function Register() {
  return (
    <div>
      <h2>Register</h2>
      {/* Adicione o formulário de registro aqui */}
    </div>
  );
}

export default Register;